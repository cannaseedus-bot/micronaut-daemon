# K’UHUL Key-Grammar / Track Suite v2

Updated copies of the three uploaded scripts, with cross-layer tests. They retain their repository paths and expected fixture contracts.

Run the self-contained bridge tests:

```bash
python -m unittest discover -s . -p 'test_grammar_bridge.py' -v
```

In the full KHANARY key-grammar repository, put the scripts in their original `tools/` directory and run:

```bash
python tools/check_key_book_grammar.py
python tools/check_ngram_key_grammar.py
python tools/build_key_relation_graph.py --query ABACUS --output data/grammar/key_relation_graph.manifest.json
```

The validators need the original repository fixtures, manifests, contracts and docs; these are **not** bundled here. Set `KUHUL_KIT_ROOT` to override repository root for both validators and the graph builder.

## Corrections

- Exact graph identity no longer falls through to a fuzzy suggestion. Suggestions remain candidates, not verified semantic keys.
- Relation weight and confidence of zero are preserved rather than silently changed to 1.0.
- Malformed negative fixture patches report a failed conformance case instead of crashing the entire checker.
- Cross-layer tests cover polysemy, edge direction, non-authoritative recognition and compact output.

This is Python-level graph/grammar validation, not native K'UHUL, XCFE, SCFML, or JROM execution.

## v3: mini transpilers integration

`mini_transpilers.py` is included as supplied. It supports these 13 commands:
`ebnf-sync`, `greeting-bank-compile`, `advisor-bootstrap-compile`,
`advisor-check`, `plan-bootstrap-compile`, `plan-check`, `validate`,
`gyro-align`, `greetings-check`, `control-check`, `fold-geometry-check`,
`capability-gap`, and `code-grammar-check`.

The new `test_mini_transpilers.py` exercises isolated tokenizer, gram-channel,
role/phase, AIML route precedence, and validator behavior without needing
KHANARY's source tree. The command implementations themselves are preserved;
their full checks require the corresponding original repository data and C++
source files. To use them, place `mini_transpilers.py` at
`tools/grammar/mini_transpilers.py` in the KHANARY repository and run:

```bash
python tools/grammar/mini_transpilers.py advisor-bootstrap-compile --repo-root .
python tools/grammar/mini_transpilers.py advisor-check --repo-root .
python tools/grammar/mini_transpilers.py control-check --repo-root .
```

AIML generation is a **projection**. This suite does not confer XCFE
admission or demonstrate native fold execution.
