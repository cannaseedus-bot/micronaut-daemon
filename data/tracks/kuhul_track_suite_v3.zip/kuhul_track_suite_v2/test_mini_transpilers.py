"""Isolated regression tests for the authored mini-transpiler's pure functions and projections."""
import json
import tempfile
import unittest
from pathlib import Path
from test_grammar_bridge import load_module

class MiniTranspilerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = load_module('mini_transpilers')

    def test_ascii_tokenizer_contract(self):
        self.assertEqual(self.m.tokenize("Don't RUN µAI_2!"), ["don't", 'run', 'ai_2'])

    def test_channel_role_phase_bindings(self):
        channels = self.m.typed_gram_channels('run tool and check API', 'test')
        for channel, grams in channels.items():
            role, phase, _ = self.m.CHANNEL_CONTRACT[channel]
            for gram in grams:
                self.assertEqual(gram['role'], role)
                self.assertEqual(gram['phase'], phase)
                self.assertEqual(gram['width'], len(gram['gram'].split(' ')))

    def test_coarse_has_no_lexical_position(self):
        grams = self.m.typed_gram_channels('if you run tool', 'test')['coarse_gram']
        self.assertTrue(grams)
        self.assertTrue(all('position' not in g for g in grams))

    def test_function_and_tool_grams(self):
        channels = self.m.classify_gram_taxonomy('if you run tool')
        self.assertIn('if you', channels['function_gram'])
        self.assertIn('run tool', channels['tool_gram'])

    def test_advisor_specific_route_wins(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root/'data/grammar').mkdir(parents=True)
            (root/'data/alice').mkdir(parents=True)
            source = {'schema':'key.grammar.advisor_bootstrap.v1','track':'ADVISOR-µ','routes':[
                {'pattern':'ADVISE *','prefix':'plan:','expert':'Coordinator','phase':'Wo','next':"Ch'en"},
                {'pattern':'ADVISE MATH *','prefix':'math:','expert':'MATH-µ','phase':'Yax','next':'Sek'}]}
            (root/'data/grammar/advisor-bootstrap.json').write_text(json.dumps(source), encoding='utf-8')
            self.assertEqual(self.m.cmd_advisor_bootstrap_compile(root),0)
            cats = self.m._parse_aiml_categories((root/'data/alice/advisor.aiml').read_text(encoding='utf-8'))
            self.assertIn('expert=MATH-µ', self.m._aiml_match(cats,'ADVISE MATH FRACTIONS'))
            self.assertIn('expert=Coordinator', self.m._aiml_match(cats,'ADVISE MY PROJECT'))

    def test_lexicon_validator_detects_role_drift(self):
        row={'word':'x','key':'X','unit':'unigram','class':'TEST','book':'Book(TEST)',
             'definition':'x','lexicon_source':'test',
             'gram_channels':{'unigram':[{'gram':'x','count':1,'width':1,'role':'tool_dispatch_intent','phase':'Pop'}]}}
        errors=[]; warnings=[]
        self.m.validate_lexicon_row(row,'test',1,errors,warnings)
        self.assertTrue(any('violates channel contract' in e for e in errors))

    def test_phase_set_is_canonical(self):
        self.assertEqual(self.m.PHASES, ['Pop','Wo','Yax','Sek',"Ch'en",'Xul'])

if __name__ == '__main__':
    unittest.main()
